// Contains the implementation of a LSP server.

package lsp

import (
	"encoding/json"
	"strconv"

	lspnet "github.com/cmu440/lspnet"
)

type server struct {
	receiveChan     chan *receivedMessage
	sendChan        chan *Message
	readChan        chan *Message
	closeClientChan chan int
	closeChan       chan int
	listen          *lspnet.UDPConn
	clientID        int
	ClientMap       map[int]*Nclient
}

type receivedMessage struct {
	addr    *lspnet.UDPAddr
	payload *Message
}

type Nclient struct {
	ConnID  int // The connection id given by the server
	addr    *lspnet.UDPAddr
	Conn    *lspnet.UDPConn
	seqNum  int
	mapHead int
	msgMap  map[int]*Message
}

// NewServer creates, initiates, and returns a new server. This function should
// NOT block. Instead, it should spawn one or more goroutines (to handle things
// like accepting incoming client connections, triggering epoch events at
// fixed intervals, synchronizing events using a for-select loop like you saw in
// project 0, etc.) and immediately return. It should return a non-nil error if
// there was an error resolving or listening on the specified port number.
func NewServer(port int, params *Params) (Server, error) {
	port_num := strconv.Itoa(port)
	ln, err := lspnet.ResolveUDPAddr("udp", "localhost:"+port_num)
	if err != nil {
		return nil, err
	}
	listen, err := lspnet.ListenUDP("udp", ln)
	if err != nil {
		return nil, err
	}

	svr := &server{
		closeClientChan: make(chan int),
		sendChan:        make(chan *Message),
		readChan:        make(chan *Message),
		receiveChan:     make(chan *receivedMessage),
		ClientMap:       make(map[int]*Nclient),
		clientID:        1,
		listen:          listen,
	}

	go readRoutineServer(svr)
	go mainRoutineServer(svr)
	return svr, nil
}

func (s *server) Read() (int, []byte, error) {
	msg := <-s.readChan
	return msg.ConnID, msg.Payload, nil
}

func (s *server) Write(connId int, payload []byte) error {
	//fmt.Printf("Server writes s%d, %s\n", s.ClientMap[connId].seqNum, payload)
	// fmt.Printf("connId is %d\n", connId)
	checksum := CalculateChecksum(connId, s.ClientMap[connId].seqNum, len(payload), payload)
	sendMsg := NewData(connId, s.ClientMap[connId].seqNum, len(payload), payload, checksum)
	// fmt.Println("write to client", sendMsg.Payload)
	data, err := json.Marshal(sendMsg)
	// fmt.Println("Server after marshal:", data)
	if err == nil {
		s.listen.WriteToUDP(data, s.ClientMap[sendMsg.ConnID].addr)
		s.ClientMap[sendMsg.ConnID].seqNum += 1
	}
	return nil
}

func (s *server) CloseConn(connId int) error {
	s.ClientMap[connId] = nil
	return nil
}

func (s *server) Close() error {
	s.closeChan <- 1
	return nil
}

func mainRoutineServer(svr *server) {
	for {
		select {
		case sendMsg := <-svr.sendChan:

			// fmt.Println("write to client", sendMsg.Payload)
			data, err := json.Marshal(sendMsg)
			// fmt.Println("Server after marshal:", data)
			if err == nil {
				svr.listen.WriteToUDP(data, svr.ClientMap[sendMsg.ConnID].addr)
				svr.ClientMap[sendMsg.ConnID].seqNum += 1
			}

		case Received := <-svr.receiveChan:
			handleRequestServer(svr, Received.payload, Received.addr)
		case <-svr.closeChan:
			svr.listen.Close()
		}
	}
}

func readRoutineServer(svr *server) {
	for {
		select {
		case <-svr.closeChan:
			return
		default:
			//var payload []byte
			payload := make([]byte, 2000)
			n, addr, err := svr.listen.ReadFromUDP(payload)
			if err != nil {
				continue
			}
			var msg Message
			err = json.Unmarshal(payload[:n], &msg)
			if err != nil {
				return
			}
			// fmt.Printf("Server read message: c%d\n", msg.SeqNum)
			res := &receivedMessage{addr: addr, payload: &msg}

			svr.receiveChan <- res
		}
	}
}

// function to handle specific incoming msg packet
func handleRequestServer(svr *server, msg *Message, addr *lspnet.UDPAddr) {
	switch msg.Type {
	case MsgConnect:
		// fmt.Printf("server receiving connection message: %s\n", msg)
		ackMsg := NewAck(svr.clientID, msg.SeqNum)
		ackData, err := json.Marshal(ackMsg)
		if err == nil {
			// fmt.Printf("Trying to ack: %s\n", ackData)
			svr.listen.WriteToUDP(ackData, addr)
			// fmt.Printf("server send ack to connection message with id = %d\n", svr.clientID)
		}
		// fmt.Println(svr.clientID)
		client := &Nclient{
			ConnID:  svr.clientID,
			addr:    addr,
			seqNum:  msg.SeqNum + 1,
			mapHead: msg.SeqNum + 1,
			msgMap:  make(map[int]*Message),
		}

		svr.ClientMap[svr.clientID] = client
		svr.clientID += 1

	case MsgData: // if msg is data
		// fmt.Printf("server receive data c%d\n", msg.SeqNum)
		if len(msg.Payload) < msg.Size {
			return
		}
		ackMsg := NewAck(msg.ConnID, msg.SeqNum)
		data, err := json.Marshal(ackMsg)
		if err == nil {
			// fmt.Printf("Server Sending ack message: c%d\n", msg.SeqNum)
			svr.listen.WriteToUDP(data, svr.ClientMap[ackMsg.ConnID].addr)
		}

		svr.ClientMap[msg.ConnID].msgMap[msg.SeqNum] = msg
		// svr.ClientMap[msg.ConnID].seqNum += 1

		for {
			tempMsg, ok := svr.ClientMap[msg.ConnID].msgMap[svr.ClientMap[msg.ConnID].mapHead]
			if ok {
				svr.readChan <- tempMsg
				svr.ClientMap[msg.ConnID].mapHead += 1
			} else {
				break
			}
		}
		// print("finish processing client data\n")
	case MsgAck: // if msg is Ack
		return
	case MsgCAck: // if msg is CAck
		return
	}

}
